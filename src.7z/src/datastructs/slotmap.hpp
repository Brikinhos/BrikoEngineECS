    #pragma once
    #include <iostream>
    #include <vector>
    
    using TypeInt = std::size_t;

    struct Key {
        TypeInt idx_ {0};
        TypeInt gen_ {0};
    };

    struct ISlotmap {
        virtual ~ISlotmap() = default;
        virtual const void* dataAddress() const noexcept = 0;
        virtual TypeInt size() const noexcept = 0;
        virtual TypeInt sizeElement() const noexcept = 0;
    };

    template <typename TypeData>
    struct Slotmap : ISlotmap {

        explicit Slotmap (TypeInt capacity) : CAPACITY_(capacity) {
            //En un futuro tendrá que ser reserve para más eficiencia, ya veremos cómo lo hacemos
            indices_.resize(capacity);
            data_.reserve(capacity);
            erase_.reserve(capacity);
            initiateIndexes();
        };

        TypeInt constexpr capacity() const noexcept { return CAPACITY_; };

        const void* dataAddress() const noexcept {
            return data_.empty() ? nullptr
            : static_cast<const void*>(data_.data());
        }

        TypeInt sizeElement() const noexcept{
            return data_.empty() ? 0 : sizeof(TypeData);
        }

        TypeInt size() const noexcept {
            return data_.size();
        }
       
        void print() const noexcept {
            
            std::cout << "FREELIST: " << freelist_ << "\n";
            std::cout << "SIZE: " << size_ << "\t";
            int i = 0;
            for (auto& index : indices_) {
                std::cout << "\t" << i++;
            }
            std::cout << "\n";
            std::cout << "INDICES:\t";
            for (auto& index : indices_) {
                std::cout << "ID:  " << index.idx_ << "\t";
            }
            std::cout << "\n\t\t";
            for (auto& index : indices_) {
                std::cout << "GEN: " << index.gen_ << "\t";
            }
            std::cout << "\n";
            std::cout << "DATA:\t\t";
            
            for (auto& data : data_) {
                std::cout << "DAT: " << &data << "\t";
            }
            
            std::cout << "\n";
            std::cout << "ERASE:\t\t";
            for (auto& erase : erase_) {
                std::cout << "ERA: " << erase << "\t";
            }
            std::cout << "\n\n";
        }        

        Key push_back(TypeData&& data) {
            //Verificamos que hay sitio para insertar el dato
            if (size_ >= CAPACITY_) { throw std::runtime_error("No se puede insertar dato, capacidad llena"); }
            auto nowfreelist = freelist_;
            auto nextfreelist = indices_[freelist_].idx_;
            //Creamos la key que se va a devolver
            Key k;
            k.idx_ = nowfreelist;
            k.gen_ = indices_[nowfreelist].gen_;
            //Modificamos freelist_ que apunta al nuevo slot libre
            freelist_ = nextfreelist;
            //Modificar la key en el primer slot libre para que apunte a la posición del dato
            indices_[nowfreelist].idx_ = size_;
            //Insertamos el dato
            data_.push_back(std::move(data));
            //Asociamos la posición del Slot relacionado con el dato en erase_
            erase_.push_back(nowfreelist);
            //Modificamos la posición del siguiente hueco libre para datos
            ++size_;
            //Devolvemos la key al usuario
            
            return k;
        }

        Key push_back(TypeData const& data){
            return push_back(TypeData {data});
        }

        void remove(Key const& key) {
            Key& slot = indices_[key.idx_];
            auto id_slot_freed = slot.idx_;

            //Comprobar que las generaciones de la key y del slot son iguales
            if (key.gen_ != slot.gen_) { throw std::runtime_error("Generaciones diferentes al borrar"); }

            //Incremento de la generación del slot objetivo
            slot.gen_++;

            //Movemos el último dato y el dato asociado en erase_ al hueco libre
            data_[id_slot_freed]  = data_[size_-1]; //Quizás std::move, evitamos copia
            erase_[id_slot_freed] = erase_[size_-1];//Aquí da igual, es un tipo primitivo

            //Eliminamos el último dato del vector
            data_.pop_back();
            
            //Modificamos el slot al que apuntaba el dato más a la derecha para que apunte en la nueva posición
            auto pos_slot_moved = erase_[id_slot_freed];
            indices_[pos_slot_moved].idx_ = id_slot_freed;

            //Eliminamos el elemento de erase más a la derecha
            erase_.pop_back();

            //Cambiamos el slot que apuntaba el dato a liberar para que apunte al siguiente slot libre, y también que freelist_ apunte a este slot
            slot.idx_ = freelist_;
            freelist_ = key.idx_;

            //reducimos el tamaño de size
            --size_;
        }

        std::vector<TypeData>& getDataVector () const noexcept {
            return data_;
        }

        std::vector<TypeData>& getDataVector() {
            return data_;
        }

        TypeData& getData (Key key) {
            if (key.gen_ != indices_[key.idx_].gen_)
                throw std::runtime_error("La key no apunta a un índice que contenga un dato");
            auto idx_data = indices_[key.idx_].idx_;
            return data_[idx_data];
        }

    private:        
        TypeInt freelist_ {0};
        TypeInt size_ {0};
        const TypeInt CAPACITY_;
        std::vector<Key> indices_ {};
        std::vector<TypeData> data_ {};
        std::vector<TypeInt> erase_ {};

        void initiateIndexes() noexcept {
            TypeInt i {0};
            for (auto& index : indices_) {
                index.idx_ = ++i;
                index.gen_ = 0;
            }
        };
    };